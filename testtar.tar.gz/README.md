# lazy-mans-tar
small c script for running the tar compression / decompression commands in terminal
