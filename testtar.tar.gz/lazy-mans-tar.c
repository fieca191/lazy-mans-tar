/*
 Author: fieca191
 A simple c script for running the tar commands for compression / decompression
 because I keep forgetting the options and would always have to refer to my
 cheat sheet / notes
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>


#define CMD_NAME 100
#define DIR_LEN 1000

void printReminder(){
  
    printf("This assumes you have already cd'ed into the directory with\n");
    printf(" files to compress. If you have not, ctrl-c now and do that.\n");
    printf("\n");
}

int main(int argc, char *argv[]){

    char filename[CMD_NAME];
    char tarcmd[CMD_NAME];
    char op[2];
    char yn[1];
    char dir[DIR_LEN];
    
    int count = 0;


    strcpy(op, argv[1]);

    if(argc < 2){
      printf("No argument supplied\n");
      printf("For help, use -h\n");
      return EXIT_SUCCESS;
    }else{

      //printReminder();

      //ask the user to enter the directory where the files are
      
      printf("Please enter directory where the file(s) to compress are ");
      printf("or tarball(s) to decompress are\n");
      scanf("%s", dir);
      
      /*
      printf("is the following the directory?: ");
      printf("%s\n", dir);
      printf("[Y/n]");
      scanf("%s", yn);
      
      //check the directory - users dont check spelling lol

      if(strcmp(yn, "n") == 0){
          printf("Wrong directory.  Please try again.\n");
          return EXIT_FAILURE;
      }
      */

      chdir(dir);//change the working directory for the rest of excecution
      if(errno != 0){//check for errors
          perror("Error: ");
          return EXIT_FAILURE;
      }

      //continue with excecution of script
      if(strcmp(op, "-c") == 0){

	printf("Compression\n");

	printf("enter tarball name:\n");
	scanf("%s", filename);

	strcpy(tarcmd, "tar -zcvf ");
	strcat(tarcmd, filename);
	strcat(tarcmd, ".tar.gz .");

	system(tarcmd);
    
      }else if(strcmp(op, "-x") == 0){

	printf("Decompression\n");

	printf("Name of tarball to de-compress:\n");
	scanf("%s", filename);
	strcpy(tarcmd, "tar -zxvf ");
	strcat(tarcmd, filename);
	strcat(tarcmd, ".tar.gz");

	system(tarcmd);
      
      }else if(strcmp(op, "-h") == 0){

	printf("\n");
	printf("Only operates in the current directory, for now\n");
      
	printf("usage: ctar\t-[cxh]\n");
	printf("however, you can only use one argument,");
	printf("because doing them at once would be dumb\n");
	printf("\n");
      
	printf("-c\t|\t");
	printf("takes in a name for a tarball to be made ");
	printf("then makes it\n");

	printf("-x\t|\t");
	printf("decompresses a given tarball\n");

	printf("-h\t|\t");
	printf("opens this help dialogue\n");

	printf("\n");
      }

    
    }

    return EXIT_SUCCESS;
}
